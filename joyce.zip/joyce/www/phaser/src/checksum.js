var CHECKSUM = {
build: '971b5a80-ecca-11e6-90b6-d3ad81c3e5e2'
};
module.exports = CHECKSUM;