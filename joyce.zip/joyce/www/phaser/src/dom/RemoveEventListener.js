var RemoveEventListener = function (target, event, listener)
{
    target.removeEventListener(event, listener);
};

module.exports = RemoveEventListener;
